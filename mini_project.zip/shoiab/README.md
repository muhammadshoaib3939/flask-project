This is my mini project on "Fee Record System" on python for web.
